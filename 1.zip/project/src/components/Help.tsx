import { useState } from 'react';
import { HelpCircle, Book, MessageCircle, Settings } from 'lucide-react';

export default function Help() {
  const [isOpen, setIsOpen] = useState(false);

  const helpTopics = [
    {
      title: 'Getting Started',
      icon: Book,
      content: [
        'Browse our product catalog',
        'Create an account to start shopping',
        'Add items to your cart',
        'Complete checkout process',
      ],
    },
    {
      title: 'Shopping Guide',
      icon: MessageCircle,
      content: [
        'How to use filters and search',
        'Reading product reviews',
        'Understanding product recommendations',
        'Tracking your orders',
      ],
    },
    {
      title: 'Account Settings',
      icon: Settings,
      content: [
        'Managing your profile',
        'Changing password',
        'Setting up preferences',
        'Notification settings',
      ],
    },
  ];

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-blue-600 text-white p-3 rounded-full shadow-lg hover:bg-blue-700"
      >
        <HelpCircle className="w-6 h-6" />
      </button>

      {isOpen && (
        <div className="absolute bottom-16 right-0 w-80 bg-white rounded-lg shadow-xl">
          <div className="p-4 border-b">
            <h2 className="text-lg font-semibold">Help Center</h2>
          </div>

          <div className="p-4 space-y-4">
            {helpTopics.map((topic) => (
              <div key={topic.title}>
                <div className="flex items-center space-x-2 mb-2">
                  <topic.icon className="w-5 h-5 text-blue-600" />
                  <h3 className="font-medium">{topic.title}</h3>
                </div>
                <ul className="space-y-2 pl-7">
                  {topic.content.map((item) => (
                    <li key={item} className="text-sm text-gray-600">
                      • {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="p-4 bg-gray-50 rounded-b-lg">
            <p className="text-sm text-gray-600">
              Need more help? Contact our support team
            </p>
          </div>
        </div>
      )}
    </div>
  );
}