import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { Sparkles } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Product, AIRecommendation } from '../types';

interface Props {
  currentProductId?: string;
  userPreferences?: string[];
}

export default function ProductRecommendations({ currentProductId, userPreferences }: Props) {
  const [recommendations, setRecommendations] = useState<(Product & AIRecommendation)[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchRecommendations();
  }, [currentProductId, userPreferences]);

  async function fetchRecommendations() {
    try {
      setLoading(true);
      const { data: products, error } = await supabase
        .from('products')
        .select('*')
        .order('rating', { ascending: false })
        .limit(4);

      if (error) throw error;

      // Simulate AI recommendations (in production, this would call an AI service)
      const recommendedProducts = products?.map(product => ({
        ...product,
        score: Math.random() * 100,
        reason: 'Based on your shopping history and preferences'
      }));

      setRecommendations(recommendedProducts || []);
    } catch (error) {
      toast.error('Failed to load recommendations');
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return <div className="text-center py-4">Loading recommendations...</div>;
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center mb-4">
        <Sparkles className="w-5 h-5 text-yellow-500 mr-2" />
        <h2 className="text-lg font-semibold">Recommended for You</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {recommendations.map((product) => (
          <Link
            key={product.id}
            to={`/product/${product.id}`}
            className="group"
          >
            <div className="bg-white rounded-lg shadow-sm overflow-hidden border hover:border-blue-500 transition-colors">
              <img
                src={product.image_url}
                alt={product.name}
                className="w-full h-48 object-cover group-hover:opacity-75 transition-opacity"
              />
              <div className="p-4">
                <h3 className="font-medium text-gray-900 mb-1">{product.name}</h3>
                <p className="text-sm text-gray-500 mb-2">
                  {product.reason}
                </p>
                <div className="flex justify-between items-center">
                  <span className="font-bold text-blue-600">
                    ${product.price.toFixed(2)}
                  </span>
                  <div className="flex items-center">
                    <span className="text-sm text-gray-600">
                      {product.rating.toFixed(1)}★
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}