import { useState } from 'react';
import { toast } from 'react-hot-toast';
import { Star, MessageSquare } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { Review, Product } from '../types';
import { useAuthStore } from '../store/authStore';

interface Props {
  product: Product;
  onReviewAdded: () => void;
}

export default function ProductReviews({ product, onReviewAdded }: Props) {
  const { user } = useAuthStore();
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error('Please login to leave a review');
      return;
    }

    try {
      setLoading(true);
      const { error } = await supabase
        .from('reviews')
        .insert([
          {
            product_id: product.id,
            rating,
            comment,
          },
        ]);

      if (error) throw error;

      toast.success('Review added successfully');
      setRating(5);
      setComment('');
      onReviewAdded();
    } catch (error) {
      toast.error('Failed to add review');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2">
        <MessageSquare className="w-5 h-5" />
        <h2 className="text-xl font-semibold">Customer Reviews</h2>
      </div>

      {/* Review Form */}
      <form onSubmit={handleSubmit} className="bg-gray-50 rounded-lg p-4">
        <h3 className="font-medium mb-4">Write a Review</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Rating
            </label>
            <div className="flex items-center space-x-1">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setRating(value)}
                  className={`p-1 ${
                    value <= rating ? 'text-yellow-400' : 'text-gray-300'
                  }`}
                >
                  <Star className="w-6 h-6 fill-current" />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label
              htmlFor="comment"
              className="block text-sm font-medium text-gray-700 mb-1"
            >
              Comment
            </label>
            <textarea
              id="comment"
              rows={4}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading || !user}
            className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Submitting...' : 'Submit Review'}
          </button>
        </div>
      </form>

      {/* Reviews List */}
      <div className="space-y-4">
        {product.reviews.map((review: Review) => (
          <div key={review.id} className="bg-white rounded-lg shadow p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                {review.user.avatar_url ? (
                  <img
                    src={review.user.avatar_url}
                    alt={review.user.full_name}
                    className="w-8 h-8 rounded-full"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                    {review.user.full_name[0]}
                  </div>
                )}
                <span className="font-medium">{review.user.full_name}</span>
              </div>
              <div className="flex items-center">
                <span className="text-yellow-400 mr-1">
                  {review.rating}
                </span>
                <Star className="w-4 h-4 text-yellow-400 fill-current" />
              </div>
            </div>
            <p className="text-gray-600">{review.comment}</p>
            <p className="text-sm text-gray-400 mt-2">
              {new Date(review.created_at).toLocaleDateString()}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}