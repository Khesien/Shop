import { useState } from 'react';
import { toast } from 'react-hot-toast';
import { Bell, Moon, Sun, Tag } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { supabase } from '../lib/supabase';

export default function Settings() {
  const { user } = useAuthStore();
  const [preferences, setPreferences] = useState({
    theme: 'light',
    notifications: true,
    recommendationPreferences: ['electronics', 'books', 'clothing'],
  });

  const categories = [
    'electronics',
    'books',
    'clothing',
    'home',
    'sports',
    'beauty',
    'toys',
    'food',
  ];

  const handleThemeChange = (theme: 'light' | 'dark') => {
    setPreferences((prev) => ({ ...prev, theme }));
    // Apply theme changes
    document.documentElement.classList.toggle('dark', theme === 'dark');
  };

  const handleNotificationChange = (enabled: boolean) => {
    setPreferences((prev) => ({ ...prev, notifications: enabled }));
  };

  const handlePreferenceChange = (category: string) => {
    setPreferences((prev) => ({
      ...prev,
      recommendationPreferences: prev.recommendationPreferences.includes(category)
        ? prev.recommendationPreferences.filter((c) => c !== category)
        : [...prev.recommendationPreferences, category],
    }));
  };

  const savePreferences = async () => {
    try {
      const { error } = await supabase
        .from('users')
        .update({ preferences })
        .eq('id', user?.id);

      if (error) throw error;
      toast.success('Preferences saved successfully');
    } catch (error) {
      toast.error('Failed to save preferences');
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-6">Settings</h2>

      <div className="space-y-6">
        {/* Theme Settings */}
        <div>
          <h3 className="text-lg font-medium mb-4">Theme</h3>
          <div className="flex space-x-4">
            <button
              onClick={() => handleThemeChange('light')}
              className={`flex items-center space-x-2 p-2 rounded-md ${
                preferences.theme === 'light'
                  ? 'bg-blue-100 text-blue-600'
                  : 'text-gray-600'
              }`}
            >
              <Sun className="w-5 h-5" />
              <span>Light</span>
            </button>
            <button
              onClick={() => handleThemeChange('dark')}
              className={`flex items-center space-x-2 p-2 rounded-md ${
                preferences.theme === 'dark'
                  ? 'bg-blue-100 text-blue-600'
                  : 'text-gray-600'
              }`}
            >
              <Moon className="w-5 h-5" />
              <span>Dark</span>
            </button>
          </div>
        </div>

        {/* Notification Settings */}
        <div>
          <h3 className="text-lg font-medium mb-4">Notifications</h3>
          <div className="flex items-center space-x-2">
            <Bell className="w-5 h-5 text-gray-600" />
            <span>Receive notifications</span>
            <label className="relative inline-flex items-center cursor-pointer ml-auto">
              <input
                type="checkbox"
                checked={preferences.notifications}
                onChange={(e) => handleNotificationChange(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>

        {/* Recommendation Preferences */}
        <div>
          <h3 className="text-lg font-medium mb-4">
            Product Recommendations
          </h3>
          <div className="grid grid-cols-2 gap-2">
            {categories.map((category) => (
              <label
                key={category}
                className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-50"
              >
                <input
                  type="checkbox"
                  checked={preferences.recommendationPreferences.includes(
                    category
                  )}
                  onChange={() => handlePreferenceChange(category)}
                  className="rounded text-blue-600 focus:ring-blue-500"
                />
                <Tag className="w-4 h-4 text-gray-600" />
                <span className="capitalize">{category}</span>
              </label>
            ))}
          </div>
        </div>

        <button
          onClick={savePreferences}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700"
        >
          Save Preferences
        </button>
      </div>
    </div>
  );
}