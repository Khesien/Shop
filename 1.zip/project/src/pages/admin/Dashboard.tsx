import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'react-hot-toast';
import { ShoppingBag, Package, DollarSign, Users } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface DashboardStats {
  totalOrders: number;
  totalProducts: number;
  totalRevenue: number;
  totalCustomers: number;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalOrders: 0,
    totalProducts: 0,
    totalRevenue: 0,
    totalCustomers: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, []);

  async function fetchStats() {
    try {
      setLoading(true);
      
      // Fetch total orders and revenue
      const { count: orderCount, error: orderError } = await supabase
        .from('orders')
        .select('*', { count: 'exact' });

      if (orderError) throw orderError;

      // Fetch total revenue
      const { data: revenue, error: revenueError } = await supabase
        .from('orders')
        .select('total')
        .eq('status', 'completed');

      if (revenueError) throw revenueError;

      const totalRevenue = revenue?.reduce((sum, order) => sum + order.total, 0) || 0;

      // Fetch total products
      const { count: productCount, error: productError } = await supabase
        .from('products')
        .select('*', { count: 'exact' });

      if (productError) throw productError;

      // Fetch total customers
      const { count: customerCount, error: customerError } = await supabase
        .from('users')
        .select('*', { count: 'exact' })
        .eq('role', 'user');

      if (customerError) throw customerError;

      setStats({
        totalOrders: orderCount || 0,
        totalProducts: productCount || 0,
        totalRevenue,
        totalCustomers: customerCount || 0,
      });
    } catch (error) {
      toast.error('Failed to load dashboard stats');
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return <div className="text-center py-12">Loading dashboard...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-8">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Orders Card */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 rounded-full">
              <Package className="w-6 h-6 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-600">Total Orders</p>
              <p className="text-2xl font-semibold">{stats.totalOrders}</p>
            </div>
          </div>
        </div>

        {/* Products Card */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 rounded-full">
              <ShoppingBag className="w-6 h-6 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-600">Total Products</p>
              <p className="text-2xl font-semibold">{stats.totalProducts}</p>
            </div>
          </div>
        </div>

        {/* Revenue Card */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-3 bg-yellow-100 rounded-full">
              <DollarSign className="w-6 h-6 text-yellow-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-semibold">
                ${stats.totalRevenue.toFixed(2)}
              </p>
            </div>
          </div>
        </div>

        {/* Customers Card */}
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <div className="p-3 bg-purple-100 rounded-full">
              <Users className="w-6 h-6 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-600">Total Customers</p>
              <p className="text-2xl font-semibold">{stats.totalCustomers}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold">Recent Orders</h2>
            <Link
              to="/admin/orders"
              className="text-blue-600 hover:text-blue-700 text-sm"
            >
              View all
            </Link>
          </div>
          {/* Add recent orders list here */}
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-lg font-semibold">Low Stock Products</h2>
            <Link
              to="/admin/products"
              className="text-blue-600 hover:text-blue-700 text-sm"
            >
              View all
            </Link>
          </div>
          {/* Add low stock products list here */}
        </div>
      </div>
    </div>
  );
}