import { create } from 'zustand';
import { User } from '../types';
import { supabase } from '../lib/supabase';

interface AuthState {
  user: User | null;
  loading: boolean;
  setUser: (user: User | null) => void;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, fullName: string) => Promise<void>;
  signOut: () => Promise<void>;
  initialize: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  loading: true,

  initialize: async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user) {
        try {
          const { data: userData, error } = await supabase
            .from('users')
            .select('*')
            .eq('id', session.user.id)
            .single();

          if (!error && userData) {
            set({ user: userData });
          }
        } catch (error) {
          console.error('Failed to fetch user data:', error);
        }
      }

      supabase.auth.onAuthStateChange(async (event, session) => {
        if (session?.user) {
          try {
            const { data: userData, error } = await supabase
              .from('users')
              .select('*')
              .eq('id', session.user.id)
              .single();

            if (!error && userData) {
              set({ user: userData });
            }
          } catch (error) {
            console.error('Failed to fetch user data:', error);
          }
        } else {
          set({ user: null });
        }
      });
    } finally {
      set({ loading: false });
    }
  },

  setUser: (user) => set({ user }),
  
  signIn: async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;

    const { data: { user: authUser } } = await supabase.auth.getUser();
    if (authUser) {
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('id', authUser.id)
        .single();

      if (!userError && userData) {
        set({ user: userData });
      }
    }
  },

  signUp: async (email, password, fullName) => {
    // First create the auth user
    const { data: { user: authUser }, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: fullName
        }
      }
    });

    if (signUpError) throw signUpError;
    if (!authUser) throw new Error('Failed to create user');

    try {
      // Then create the user profile
      const { error: profileError } = await supabase
        .from('users')
        .insert([{
          id: authUser.id,
          email: email,
          full_name: fullName,
          role: 'user',
          preferences: {
            theme: 'light',
            notifications: true,
            recommendationPreferences: []
          }
        }]);

      if (profileError) throw profileError;

      // Sign in the user immediately after registration
      await supabase.auth.signInWithPassword({
        email,
        password,
      });

      const { data: userData, error: fetchError } = await supabase
        .from('users')
        .select('*')
        .eq('id', authUser.id)
        .single();

      if (fetchError) throw fetchError;
      if (userData) {
        set({ user: userData });
      }
    } catch (error) {
      // If profile creation fails, delete the auth user
      await supabase.auth.admin.deleteUser(authUser.id);
      throw error;
    }
  },

  signOut: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    set({ user: null });
  },
}));