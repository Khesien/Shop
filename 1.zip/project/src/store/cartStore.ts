import { create } from 'zustand';
import { CartItem, Product } from '../types';
import { supabase } from '../lib/supabase';

interface CartState {
  items: CartItem[];
  loading: boolean;
  addItem: (product: Product, quantity: number) => Promise<void>;
  removeItem: (productId: string) => Promise<void>;
  updateQuantity: (productId: string, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  fetchCart: () => Promise<void>;
}

export const useCartStore = create<CartState>((set, get) => ({
  items: [],
  loading: false,

  fetchCart: async () => {
    set({ loading: true });
    const { data, error } = await supabase
      .from('cart_items')
      .select(`
        *,
        product:products(*)
      `)
      .order('created_at');

    if (error) throw error;
    set({ items: data || [], loading: false });
  },

  addItem: async (product, quantity) => {
    const { error } = await supabase
      .from('cart_items')
      .upsert({
        product_id: product.id,
        quantity,
      }, {
        onConflict: 'user_id,product_id'
      });

    if (error) throw error;
    get().fetchCart();
  },

  removeItem: async (productId) => {
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .eq('product_id', productId);

    if (error) throw error;
    get().fetchCart();
  },

  updateQuantity: async (productId, quantity) => {
    const { error } = await supabase
      .from('cart_items')
      .update({ quantity })
      .eq('product_id', productId);

    if (error) throw error;
    get().fetchCart();
  },

  clearCart: async () => {
    const { error } = await supabase
      .from('cart_items')
      .delete()
      .neq('id', '');

    if (error) throw error;
    set({ items: [] });
  },
}));