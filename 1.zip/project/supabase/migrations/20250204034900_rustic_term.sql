/*
  # Create admin user and sample products

  1. Changes
    - Insert admin user
    - Insert sample products
  
  2. Security
    - Maintains existing RLS policies
    - Admin user has full access
*/

-- Insert admin user (password: admin123)
INSERT INTO auth.users (
  id,
  instance_id,
  email,
  encrypted_password,
  email_confirmed_at,
  created_at,
  updated_at,
  raw_app_meta_data,
  raw_user_meta_data,
  is_super_admin,
  role
) VALUES (
  'ad4e861c-7d53-4a2d-b832-4c7951c1f535',
  '00000000-0000-0000-0000-000000000000',
  'admin@example.com',
  crypt('admin123', gen_salt('bf')),
  now(),
  now(),
  now(),
  '{"provider":"email","providers":["email"]}',
  '{}',
  false,
  'authenticated'
);

-- Insert admin profile
INSERT INTO public.users (
  id,
  full_name,
  role,
  preferences,
  email
) VALUES (
  'ad4e861c-7d53-4a2d-b832-4c7951c1f535',
  'Admin User',
  'admin',
  'admin@example.com',
  '{"theme": "light", "notifications": true, "recommendationPreferences": []}'
);

-- Insert sample products
INSERT INTO public.products (
  name,
  description,
  price,
  image_url,
  category,
  stock,
  rating,
  tags
) VALUES
  (
    'Premium Wireless Headphones',
    'High-quality wireless headphones with noise cancellation and premium sound quality.',
    199.99,
    'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
    'electronics',
    50,
    4.5,
    ARRAY['wireless', 'audio', 'premium']
  ),
  (
    'Smart Fitness Watch',
    'Track your fitness goals with this advanced smartwatch featuring heart rate monitoring and GPS.',
    149.99,
    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
    'electronics',
    75,
    4.3,
    ARRAY['wearable', 'fitness', 'smart']
  ),
  (
    'Leather Laptop Bag',
    'Stylish and durable leather laptop bag with multiple compartments.',
    89.99,
    'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80',
    'accessories',
    30,
    4.7,
    ARRAY['leather', 'laptop', 'bag']
  );