/*
  # Add Admin User with Email Check

  1. Changes
    - Creates an admin user with proper authentication
    - Sets up admin profile with correct role and permissions
    - Handles case where email already exists
    
  2. Security
    - Uses secure password hashing
    - Maintains existing RLS policies
*/

DO $$ 
BEGIN
  -- Only insert if email doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM auth.users WHERE email = 'admin@example.com'
  ) THEN
    -- Create admin user in auth.users
    INSERT INTO auth.users (
      id,
      instance_id,
      email,
      encrypted_password,
      email_confirmed_at,
      created_at,
      updated_at,
      raw_app_meta_data,
      raw_user_meta_data,
      is_super_admin,
      role
    ) VALUES (
      'a96f7e76-2557-4d11-9f57-eb3e51c33130',
      '00000000-0000-0000-0000-000000000000',
      'admin@example.com',
      crypt('admin123', gen_salt('bf')),
      now(),
      now(),
      now(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"Admin User"}',
      false,
      'authenticated'
    );

    -- Create admin profile in public.users
    INSERT INTO public.users (
      id,
      full_name,
      email,
      role,
      preferences
    ) VALUES (
      'a96f7e76-2557-4d11-9f57-eb3e51c33130',
      'Admin User',
      'admin@example.com',
      'admin',
      '{"theme": "light", "notifications": true, "recommendationPreferences": []}'::jsonb
    );
  END IF;
END $$;